#ifndef COMMAND_SYSTEM_COORDINATES_H_INCLUDED
#define COMMAND_SYSTEM_COORDINATES_H_INCLUDED

void handlerSystemCoordinatestCommand(STRUCT_COMMAND *input_data, void (*sendResponse)(char*, int));

#endif // COMMAND_SYSTEM_COORDINATES_H_INCLUDED
