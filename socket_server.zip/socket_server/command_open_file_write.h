#ifndef COMMAND_OPEN_FILE_WRITE_H_INCLUDED
#define COMMAND_OPEN_FILE_WRITE_H_INCLUDED

void handlerOpenFileWriteCommand(STRUCT_COMMAND *input_data, void (*sendResponse)(char*, int));

#endif // COMMAND_OPEN_FILE_WRITE_H_INCLUDED
