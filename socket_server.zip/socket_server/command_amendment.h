#ifndef COMMAND_AMENDMENT_H_INCLUDED
#define COMMAND_AMENDMENT_H_INCLUDED

void handlerAmendmentCommand(STRUCT_COMMAND *input_data, void (*sendResponse)(char*, int));

#endif // COMMAND_AMENDMENT_H_INCLUDED
