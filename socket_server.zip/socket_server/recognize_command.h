#ifndef RECOGNIZE_COMMAND_H_INCLUDED
#define RECOGNIZE_COMMAND_H_INCLUDED


void recognize_command(struct command_package *input_data, void (*sendResponce)(char*, int));


#endif // RECOGNIZE_COMMAND_H_INCLUDED
