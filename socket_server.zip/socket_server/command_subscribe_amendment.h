#ifndef COMMAND_SUBSCRIBE_AMENDMENT_H_INCLUDED
#define COMMAND_SUBSCRIBE_AMENDMENT_H_INCLUDED

void handlerSubscribeAmendmentCommand(STRUCT_COMMAND *input_data, void (*sendResponse)(char*, int));

#endif // COMMAND_SUBSCRIBE_AMENDMENT_H_INCLUDED
