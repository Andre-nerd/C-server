#ifndef COMMAND_DEVICES_FOR_SOLUTION_H_INCLUDED
#define COMMAND_DEVICES_FOR_SOLUTION_H_INCLUDED

void handlerDevicesForSolutionCommand(STRUCT_COMMAND *input_data, void (*sendResponse)(char*, int));

#endif // COMMAND_DEVICES_FOR_SOLUTION_H_INCLUDED
